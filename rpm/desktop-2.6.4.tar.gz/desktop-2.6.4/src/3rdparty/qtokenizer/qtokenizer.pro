TEMPLATE = subdirs
SUBDIRS = test
